﻿string nombre = "informaticonfig";
int edad = 20;
bool Activo = false;
DateTime fecha = DateTime.Now;
float precio = 150f;

Console.WriteLine(nombre);
Console.WriteLine(Activo);
Console.WriteLine(fecha);
Console.WriteLine(precio);
Console.ReadKey();
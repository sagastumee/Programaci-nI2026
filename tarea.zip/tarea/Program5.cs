﻿using System;

class Program
{
    static void Main()
    {
        // Casting implícito
        int valor = 200;
        double total = valor;
        Console.WriteLine("Implicito: " + total);

        // Casting explícito
        double precio = 500.23;
        int descuento = (int)precio;
        Console.WriteLine("Descuento: " + descuento);

        // Conversión de char a int (código ASCII)
        char letra = 'A';
        int codigoAsci = letra;
        Console.WriteLine("Codigo ASCII: " + codigoAsci);

        // Conversión de string a int
        string palabra = "123456";
        int numero = Convert.ToInt32(palabra);
        Console.WriteLine("Numero convertido: " + numero);

        // Conversión de string a double
        string textoDecimal = "150.60";
        double valor3 = double.Parse(textoDecimal);
        Console.WriteLine("Decimal convertido: " + valor3);

        Console.ReadKey();
    }
}
﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine(45);
Console.WriteLine("informatingconfig");
Console.WriteLine(50+60);
﻿// Declaramos una variable de tipo string (texto)
// y le asignamos el nombre "Ana"
string nombre = "Ana";

// Declaramos una variable de tipo int (número entero)
// y le asignamos el valor 19
int edad = 19;

// Mostramos en pantalla un mensaje.
// Concatenamos texto con las variables nombre y edad usando el signo +
Console.WriteLine("Nombre de Usuario: " + nombre + " edad:" + edad);

// Espera a que el usuario presione una tecla antes de cerrar la consola
Console.ReadKey();